package com.example.SpringBoot;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
public class TaskController {

    private List<Task> tasks = new ArrayList<>();

    public TaskController() {
        tasks.add(new Task(1,"t1","Pending"));
        tasks.add(new Task(2,"t2","Pending"));
        tasks.add(new Task(3,"t3","In Progress"));
        tasks.add(new Task(4,"t4","In Progress"));
        tasks.add(new Task(5,"t5","Completed"));
        tasks.add(new Task(6,"t6","Completed"));
    }

    @GetMapping("/tasks")
    public List<Task> getTasks() {
        return tasks;
    }

    @GetMapping("/status/{status}")
    public List<Task> getTaskByStatus(@PathVariable String status) {

        List<Task> result = new ArrayList<>();

        for(Task t : tasks) {

            if(t.getStatus().equalsIgnoreCase(status)) {
                result.add(t);
            }

        }

        return result;
    }

    @PostMapping("/tasks")
    public Task addTask(@RequestBody Task task) {
        tasks.add(task);
        return task;
    }

    @DeleteMapping("/tasks/{id}")
    public String deleteTask(@PathVariable int id) {

        Iterator<Task> iterator = tasks.iterator();

        while(iterator.hasNext()) {

            Task t = iterator.next();

            if(t.getId() == id) {
                iterator.remove();
                return "Task deleted";
            }

        }

        return "Task not found";
    }
}